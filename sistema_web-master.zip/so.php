
<html>
	<head>

		<title>Audio Simples</title>
		<meta charset="utf-8">
		<meta charset="utf-8">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
		<style>
			.container{
				padding:20px;
			}
		</style>
	</head>


	<body>
		<div class="container text-center">
			

			<div>
				<a href="#" onclick="play()">Play</a>
				<a href="#" onclick="pause()">Pause</a>

			
			</div>
		</div>
		
	</body>




</html>